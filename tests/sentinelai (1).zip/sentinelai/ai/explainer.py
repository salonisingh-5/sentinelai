def explain_log(log_text, threat_type):
    return {
        "explanation": f"The system detected {threat_type} based on log patterns in: {log_text}",
        "mitigation": "Block IP, enable MFA, and investigate repeated login attempts."
    }
