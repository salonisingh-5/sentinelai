def suggest_action(result):
    if result["severity_label"].lower() == "high":
        return "Block IP immediately and trigger SOC alert"
    elif result["severity_label"].lower() == "medium":
        return "Rate-limit IP and monitor activity"
    else:
        return "Log event for passive monitoring"
