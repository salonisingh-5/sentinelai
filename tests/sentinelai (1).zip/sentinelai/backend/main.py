from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.database import engine, Base
from backend.routes.ai_routes import router as ai_router
from backend.routes.alerts import router as alerts_router

app = FastAPI(title="SentinelAI Backend")

# ==============================
# CORS CONFIG
# ==============================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==============================
# CREATE TABLES SAFELY
# ==============================
# Wrap in try so backend doesn't crash if DB is down
try:
    Base.metadata.create_all(bind=engine)
except Exception as e:
    print(f"[DB INIT WARNING] {e}")

# ==============================
# ROUTES
# ==============================
app.include_router(ai_router, prefix="/ai", tags=["AI"])
app.include_router(alerts_router, prefix="/alerts", tags=["Alerts"])

# ==============================
# HEALTH CHECK
# ==============================
@app.get("/")
def home():
    return {"message": "SentinelAI Backend Running"}
