from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# ==============================
# CHANGE THIS BASED ON DB TYPE
# ==============================

# 🔹 OPTION 1: PostgreSQL (use this if Postgres is running)
#DATABASE_URL = "postgresql://postgres:Saloni%4014@localhost:5432/sentinelai"

# 🔹 OPTION 2: SQLite (uncomment if you don't want Postgres)
DATABASE_URL = "sqlite:///./sentinelai.db"

# ==============================
# ENGINE SETUP
# ==============================

if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False}
    )
else:
    engine = create_engine(DATABASE_URL)

# ==============================
# SESSION
# ==============================

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# ==============================
# BASE MODEL
# ==============================

Base = declarative_base()

# ==============================
# DB DEPENDENCY
# ==============================

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
