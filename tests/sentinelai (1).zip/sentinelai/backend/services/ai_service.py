import sys
import os

# =========================
# PATH FIX (kept safe)
# =========================
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# =========================
# INTERNAL MODULE IMPORTS
# =========================
from ai.classifier import classify_log
from ai.explainer import explain_log
from ai.chatbot import ask_question


# =========================
# CORE PIPELINE FUNCTION
# =========================
def analyze_log(log_text: str):
    """
    Full SentinelAI pipeline:
    1. Classify log
    2. Generate explanation
    3. Return structured SOC response
    """

    # Step 1: classify log
    classification = classify_log(log_text)

    # Step 2: explain result
    explanation = explain_log(
        log_text,
        classification["threat_type"]
    )

    # Step 3: return unified SOC output
    return {
        "threat": classification["threat_type"],
        "severity": classification["severity_label"],
        "confidence": classification["confidence_pct"],
        "matched_keywords": classification["matched_keywords"],
        "explanation": explanation["explanation"],
        "mitigation": explanation.get("mitigation", "No mitigation available")
    }


# =========================
# CHATBOT / Q&A MODULE
# =========================
def ask_ai(question: str, alert_context: dict):
    """
    AI chatbot for SOC analyst questions
    """

    return ask_question(question, alert_context)


# =========================
# TEST RUN
# =========================
if __name__ == "__main__":
    print("AI Service Running...")

    sample_log = "Multiple failed login attempts from 192.168.1.10"

    try:
        result = analyze_log(sample_log)
        print("\n=== ANALYSIS RESULT ===")
        print(result)

    except Exception as e:
        print("Error:", e)
